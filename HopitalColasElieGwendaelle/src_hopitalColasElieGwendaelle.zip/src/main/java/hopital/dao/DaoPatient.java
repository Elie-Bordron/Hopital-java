package hopital.dao;

import hopital.model.Patient;

public interface DaoPatient extends DaoGeneric<Patient, Integer> {

}

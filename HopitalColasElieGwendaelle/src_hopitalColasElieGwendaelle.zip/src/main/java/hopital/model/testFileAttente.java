package hopital.model;

public class testFileAttente {

		public static void main(String[] Args) {
			
		}
}
